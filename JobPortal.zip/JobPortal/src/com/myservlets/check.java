package com.myservlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mybeans.Newuser;

/**
 * Servlet implementation class check
 */
@WebServlet("/check")
public class check extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public check() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String number,psw;
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try
		{
			number=request.getParameter("unm");
			psw=request.getParameter("pws");
			
			System.out.println(number);
			System.out.println(psw);
			
			Configuration cfg = new Configuration().configure();
			SessionFactory sf = cfg.addAnnotatedClass(Newuser.class).buildSessionFactory();
			Session ses = sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q=ses.createQuery("from Newuser where mobile= :mo and password= :ps");
			
			q.setParameter("mo", number);
			q.setParameter("ps", psw);
			
			List lst=q.getResultList();
			if(lst.size()>0)
			{
				HttpSession hses=request.getSession();
				hses.setAttribute("userid", number);
				
				for(int i=0;i<lst.size();i++)
				{
					Newuser obj=(Newuser) lst.get(i);
					String type=obj.getType();
					if(type.equals("JobSeeker"))
						response.sendRedirect("Jobs.jsp");
					else
						response.sendRedirect("");
				}
				
				//out.println("login...");
			}
			else
			{
				HttpSession hses=request.getSession();
				hses.setAttribute("message", "Incorrect Login & Password..");
				response.sendRedirect("login.jsp");
			}
				
			ses.close();
			
			
		}
		catch(Exception e)
		{
			out.println(e);
		}
		
	}

}
