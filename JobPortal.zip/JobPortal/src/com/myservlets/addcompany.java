package com.myservlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mybeans.Companys;

/**
 * Servlet implementation class addcompany
 */
@WebServlet("/addcompany")
public class addcompany extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addcompany() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name,mail,number,jd,ppa,gender,city;
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try
		{
			name=request.getParameter("cnm");
			mail=request.getParameter("cemail");
			number=request.getParameter("cmob");
			jd=request.getParameter("cjd");
			ppa=request.getParameter("ppa");
			gender=request.getParameter("gender");
			city=request.getParameter("city");
			
			System.out.println(name);
			System.out.println(mail);
			System.out.println(number);
			System.out.println(jd);
			System.out.println(ppa);
			System.out.println(gender);
			System.out.println(city);
			
			
			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(Companys.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Companys obj = new Companys();
			
			obj.setName(name);
			obj.setMail(mail);
			obj.setNumber(number);
			obj.setJobd(jd);
			obj.setCpackage(ppa);
			obj.setMf(gender);
			obj.setCity(city);
			
			ses.save(obj);
			ses.getTransaction().commit();
			//out.println("User Registered Sucessfully..");
			HttpSession hses=request.getSession();
			hses.setAttribute("message", "Comapny Added Sucessfully....");
			response.sendRedirect("ADDCompany.jsp");
		}
		catch(Exception e)
		{
			out.println(e);
		}
		
	}

}
