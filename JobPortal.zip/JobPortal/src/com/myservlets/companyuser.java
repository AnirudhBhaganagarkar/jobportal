package com.myservlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mybeans.CompanyUser;

/**
 * Servlet implementation class companyuser
 */
@WebServlet("/companyuser")
public class companyuser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public companyuser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String name,mail,number,psw,city,type;
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		try
		{
		type="Company";
		name=request.getParameter("nm");
		mail=request.getParameter("email");
		number=request.getParameter("mob");
		psw=request.getParameter("psw");
		city=request.getParameter("city");
		
		System.out.println(name);
		System.out.println(mail);
		System.out.println(number);
		System.out.println(psw);
		System.out.println(city);
		System.out.println(type);
		
		Configuration cfg=new Configuration().configure();
		SessionFactory sf=cfg.addAnnotatedClass(CompanyUser.class).buildSessionFactory();
		Session ses=sf.getCurrentSession();
		ses.beginTransaction();
		
		
		CompanyUser obj = new CompanyUser();
		
		obj.setCname(name);
		obj.setCemail(mail);
		obj.setCmobile(number);
		obj.setCpassword(psw);
		obj.setCcity(city);
		obj.setCtype(type);
		
		ses.save(obj);
		ses.getTransaction().commit();
		//out.println("Company Registered Sucessfully..");
		
		HttpSession hses=request.getSession();
		hses.setAttribute("message", "Company Registered Sucessfully...");
		response.sendRedirect("RegisterAsCompany.jsp");
		
		}
		catch(Exception e)
		{
			out.println(e);
		}
		
	}

}
