package com.myservlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mybeans.CompanyUser;

/**
 * Servlet implementation class changepass
 */
@WebServlet("/changepass")
public class changepass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public changepass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String number,oldno,newno;
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		number=request.getParameter("cnumber");
		oldno=request.getParameter("oldno");
		newno=request.getParameter("newno");
		
		try
		{
			Configuration cfg = new Configuration().configure();
			SessionFactory sf = cfg.addAnnotatedClass(CompanyUser.class).buildSessionFactory();
			Session ses = sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q=ses.createQuery("from CompanyUser where cpassword= :ps and cmobile= :mo");
			
			q.setParameter("ps", oldno);
			q.setParameter("mo", number);
			
			List lst=q.getResultList();
			if(lst.size()>0)
			{
				Query q1=ses.createQuery("update CompanyUser set cpassword= :psw where cmobile= :mob ");
				
				q1.setParameter("psw", newno);
				q1.setParameter("mob", number);
				int cnt=q1.executeUpdate();
				if(cnt>0)
				{
					HttpSession hses=request.getSession();
					hses.setAttribute("message", "Password Changed..");
					response.sendRedirect("ChangePassword.jsp");
				}	
				
				ses.getTransaction().commit();
				ses.close();
			}
			else
			{
				HttpSession hses=request.getSession();
				hses.setAttribute("message", "Incorrect Old Password..");
				response.sendRedirect("ChangePassword.jsp");
			}
		}
		catch(Exception e)
		{
			
		}
	}

}
