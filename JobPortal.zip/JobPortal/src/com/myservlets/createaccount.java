package com.myservlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mybeans.Newuser;

/**
 * Servlet implementation class createaccount
 */
@WebServlet("/createaccount")
public class createaccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public createaccount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String name,mail,number,psw,gen,city,type;
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		try
		{
		type=request.getParameter("rtype");	
		name=request.getParameter("nm");
		mail=request.getParameter("email");
		number=request.getParameter("mob");
		psw=request.getParameter("psw");
		gen=request.getParameter("gender");
		city=request.getParameter("city");
		
		System.out.println(name);
		System.out.println(mail);
		System.out.println(number);
		System.out.println(psw);
		System.out.println(gen);
		System.out.println(city);
		System.out.println(type);
		
		Configuration cfg=new Configuration().configure();
		SessionFactory sf=cfg.addAnnotatedClass(Newuser.class).buildSessionFactory();
		Session ses=sf.getCurrentSession();
		ses.beginTransaction();
		
		
		Newuser obj = new Newuser();
		obj.setName(name);
		obj.setMail(mail);
		obj.setMobile(number);
		obj.setPassword(psw);
		obj.setGender(gen);
		obj.setCity(city);
		obj.setType(type);
		
		
		ses.save(obj);
		ses.getTransaction().commit();
		//out.println("User Registered Sucessfully..");
		HttpSession hses=request.getSession();
		hses.setAttribute("message", "User Registered Sucessfully...");
		response.sendRedirect("Register.jsp");
		
		
		}
		catch(Exception e)
		{
			out.println(e);
		}
		
	}

}
