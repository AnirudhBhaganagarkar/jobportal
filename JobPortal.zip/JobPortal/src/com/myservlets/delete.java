package com.myservlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mybeans.Companys;

/**
 * Servlet implementation class delete
 */
@WebServlet("/delete")
public class delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public delete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter out=response.getWriter();
		int id;
		
		try
		{
			id=Integer.parseInt(request.getParameter("id"));
			
			Configuration cfg= new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(Companys.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q =ses.createQuery("delete from Companys where cid= :id");
			
			q.setParameter("id", id);
			
			int cnt=q.executeUpdate();
			if(cnt>0)
			{
				HttpSession hses=request.getSession();
				hses.setAttribute("message", "Deleted Sucessfully....");
				response.sendRedirect("CompanyAddedJob.jsp");
			}
			ses.getTransaction().commit();
			ses.close();
		}
		catch(Exception e)
		{
			out.println(e);
		}
		
		
	}

}
