package com.myservlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mybeans.Companys;

/**
 * Servlet implementation class savechanges
 */
@WebServlet("/savechanges")
public class savechanges extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public savechanges() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		int ccid;
		ccid=Integer.parseInt(request.getParameter("ccid"));
		System.out.println("this is Company id");
		System.out.println(ccid);
		String cname,cmail,jd,ppa,gender,city;
		cname=request.getParameter("cnm");
		cmail=request.getParameter("cemail");
		jd=request.getParameter("cjd");
		ppa=request.getParameter("ppa");
		gender=request.getParameter("gender");
		city=request.getParameter("city");
		try 
		{
			Configuration cfg = new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(Companys.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q = ses.createQuery("update Companys set name= :nm,mail= :ml,jobd= :jd,cpackage= :cp,mf= :mf,city= :cit  where cid= :id");
			
			q.setParameter("nm", cname);
			q.setParameter("ml", cmail);
			q.setParameter("jd", jd);
			q.setParameter("cp", ppa);
			q.setParameter("mf", gender);
			q.setParameter("cit", city);
			q.setParameter("id", ccid);
			
			int cnt=q.executeUpdate();
			if(cnt>0)
			{
				HttpSession hses=request.getSession();
				hses.setAttribute("message", "Deteil's Modified Sucessfully....");
				response.sendRedirect("CompanyAddedJob.jsp");
			}
			ses.getTransaction().commit();
			ses.close();
			
			
		}
		catch(Exception e)
		{
			out.println(e);
		}
	}

}
