package com.myservlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mybeans.CompanyUser;

import com.mybeans.SendMessage;

/**
 * Servlet implementation class recovercomapny
 */
@WebServlet("/recovercomapny")
public class recovercomapny extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public recovercomapny() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String number;
		PrintWriter out= response.getWriter();
		
		try
		{
			number=request.getParameter("no");
			
			Configuration cfg = new Configuration().configure();
			SessionFactory sf= cfg.addAnnotatedClass(CompanyUser.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q= ses.createQuery("from CompanyUser where cmobile= :mo");
			q.setParameter("mo", number);
			
			List lst=q.getResultList();
			if(lst.size()>0)
			{
				for(int i=0;i<lst.size();i++)
				{
					CompanyUser ob=(CompanyUser) lst.get(i);
					String mob=ob.getCmobile();
					String pswd=ob.getCpassword();
					
					SendMessage obj= new SendMessage();
					obj.sendMessage("hi Your Password is:- "+pswd, "9158652001");

					HttpSession hses=request.getSession();
					hses.setAttribute("message", "Password Send to Mo. Number..");
					response.sendRedirect("RecoverPassword.jsp");

				}
			}
			else
			{
				HttpSession hses=request.getSession();
				hses.setAttribute("message", " Number Does't Exist..");
				response.sendRedirect("RecoverPassword.jsp");
			}
		}
		catch(Exception e)
		{
			out.println(e);
		}
	}

}
