package com.myservlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mybeans.Applyjobs;

/**
 * Servlet implementation class applyjob
 */
@WebServlet("/applyjob")
public class applyjob extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public applyjob() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String name,mail,cnumber,unumber,jd,ppa,gender,city;
		PrintWriter out= response.getWriter();
		
		try
		{
			System.out.println();
			name=request.getParameter("cnm");
			mail=request.getParameter("cemail");
			cnumber=request.getParameter("cnumber");
			unumber=request.getParameter("unumber");
			jd=request.getParameter("cjd");
			System.out.println("HELLO EVERYONE.......");
			System.out.println(jd);
			ppa=request.getParameter("ppa");
			gender=request.getParameter("gender");
			city=request.getParameter("city");
			
			Configuration cfg= new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(Applyjobs.class).buildSessionFactory();
			Session ses= sf.getCurrentSession();
			
			ses.beginTransaction();
			
			Applyjobs obj = new Applyjobs();
			obj.setCname(name);
			obj.setCemail(mail);
			obj.setCmobile(cnumber);
			obj.setMobile(unumber);
			obj.setCjd(jd);
			obj.setCpackage(ppa);
			obj.setCmf(gender);
			obj.setCcity(city);
			
			ses.save(obj);
			ses.getTransaction().commit();
			ses.close();
			
			HttpSession hses=request.getSession();
			hses.setAttribute("message", "You Applied Sucessfully....");
			response.sendRedirect("ViewJobDetails.jsp");
			
		}
		catch(Exception e)
		{
			out.println(e);
		}
		
	}

}
