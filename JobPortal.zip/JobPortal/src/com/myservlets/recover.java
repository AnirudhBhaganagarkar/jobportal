package com.myservlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mybeans.Newuser;
import com.mybeans.SendMessage;

/**
 * Servlet implementation class recover
 */
@WebServlet("/recover")
public class recover extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public recover() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String number;
		PrintWriter out= response.getWriter();
		
		try
		{
			number=request.getParameter("no");
			
			Configuration cfg = new Configuration().configure();
			SessionFactory sf= cfg.addAnnotatedClass(Newuser.class).buildSessionFactory();
			Session ses=sf.getCurrentSession();
			ses.beginTransaction();
			
			Query q= ses.createQuery("from Newuser where mobile= :mo");
			q.setParameter("mo", number);
			
			List lst=q.getResultList();
			if(lst.size()>0)
			{
				for(int i=0;i<lst.size();i++)
				{
					Newuser ob=(Newuser) lst.get(i);
					String mob=ob.getMobile();
					String pswd=ob.getPassword();
					
					SendMessage obj= new SendMessage();
					obj.sendMessage("hi your Password is:- "+pswd, "9158652001");

					HttpSession hses=request.getSession();
					hses.setAttribute("message", "Password Send to Mo. Number..");
					response.sendRedirect("RecoverPassword.jsp");

				}
			}
			else
			{
				HttpSession hses=request.getSession();
				hses.setAttribute("message", " Number Does't Exist..");
				response.sendRedirect("RecoverPassword.jsp");
			}
		}
		catch(Exception e)
		{
			out.println(e);
		}
	}

}




