package com.mybeans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="companyuser")
public class CompanyUser 
{
	@Column(name="name")
	private String cname;
	
	@Column(name="email")
	private String cemail;
	
	@Id
	@Column(name="mobile")
	private String cmobile;
	
	@Column(name="password")
	private String cpassword;
	

	@Column(name="city")
	private String ccity;
	
	@Column(name="type")
	private String ctype;
	
		
	public CompanyUser()
	{
		cname="";
		cemail="";
		cmobile="";
		cpassword="";
		ccity="";
		ctype="";
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCemail() {
		return cemail;
	}

	public void setCemail(String cemail) {
		this.cemail = cemail;
	}

	public String getCmobile() {
		return cmobile;
	}

	public void setCmobile(String cmobile) {
		this.cmobile = cmobile;
	}

	public String getCpassword() {
		return cpassword;
	}

	public void setCpassword(String cpassword) {
		this.cpassword = cpassword;
	}

	
	public String getCcity() {
		return ccity;
	}

	public void setCcity(String ccity) {
		this.ccity = ccity;
	}

	public String getCtype() {
		return ctype;
	}

	public void setCtype(String ctype) {
		this.ctype = ctype;
	}

}
