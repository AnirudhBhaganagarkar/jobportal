package com.mybeans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="company")
public class Companys 
{
	@Id
	@Column(name="cid")
	private int cid;
	
	@Column(name="cname")
	private String name;
	
	@Column(name="cemail")
	private String mail;
	
	@Column(name="cjd")
	private String jobd;
	
	@Column(name="cpackage")
	private String cpackage;
	
	@Column(name="cmf")
	private String mf;
	
	@Column(name="ccity")
	private String city;
	
	@Column(name="mobile")
	private String number;
	
	public Companys()
	{
		cid=0;
		name="";
		mail="";
		jobd="";
		cpackage="";
		mf="";
		city="";
		number="";
	}

	
	public int getCid() {
		return cid;
	}


	public void setCid(int cid) {
		this.cid = cid;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getJobd() {
		return jobd;
	}

	public void setJobd(String jobd) {
		this.jobd = jobd;
	}

	public String getCpackage() {
		return cpackage;
	}

	public void setCpackage(String cpackage) {
		this.cpackage = cpackage;
	}

	public String getMf() {
		return mf;
	}

	public void setMf(String mf) {
		this.mf = mf;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}
	
	
}
