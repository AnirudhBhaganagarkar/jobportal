package com.mybeans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="applyjob")
public class Applyjobs 
{
	@Id
	@Column(name="aid")
	private int aid;
	
	@Column(name="cname")
	private String cname;
	
	@Column(name="cemail")
	private String cemail;
	
	@Column(name="cjd")
	private String cjd;
	
	@Column(name="cpackage")
	private String cpackage;
	
	@Column(name="cmf")
	private String cmf;
	
	@Column(name="ccity")
	private String ccity;
	
	@Column(name="cmobile")
	private String cmobile;
	
	@Column(name="mobile")
	private String mobile;
	
	public Applyjobs()
	{
		aid=0;
		cname="";
		cemail="";
		cjd="";
		cpackage="";
		cmf="";
		ccity="";
		cmobile="";
		mobile="";
	}

	public int getAid() {
		return aid;
	}

	public void setAid(int aid) {
		this.aid = aid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCemail() {
		return cemail;
	}

	public void setCemail(String cemail) {
		this.cemail = cemail;
	}

	public String getCjd() {
		return cjd;
	}

	public void setCjd(String cjd) {
		this.cjd = cjd;
	}

	public String getCpackage() {
		return cpackage;
	}

	public void setCpackage(String cpackage) {
		this.cpackage = cpackage;
	}

	public String getCmf() {
		return cmf;
	}

	public void setCmf(String cmf) {
		this.cmf = cmf;
	}

	public String getCcity() {
		return ccity;
	}

	public void setCcity(String ccity) {
		this.ccity = ccity;
	}

	public String getCmobile() {
		return cmobile;
	}

	public void setCmobile(String cmobile) {
		this.cmobile = cmobile;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
}
